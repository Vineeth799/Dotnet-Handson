﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnitHandson1
{
    public class Calculator
    {
        public int Add(int a, int b)
        {
            int x = a + b;
            return x;
        }
    }
        class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
